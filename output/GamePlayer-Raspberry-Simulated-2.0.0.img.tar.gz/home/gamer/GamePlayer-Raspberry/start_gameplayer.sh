#!/bin/bash
# GamePlayer-Raspberry 自动启动脚本

cd /home/gamer/GamePlayer-Raspberry

# 等待网络就绪
sleep 10

# 启动Web服务器
python3 simple_demo_server.py --port 8080 --host 0.0.0.0 &

# 显示启动信息
echo "🎮 GamePlayer-Raspberry 已启动"
echo "🌐 Web界面: http://$(hostname -I | awk '{print $1}'):8080"
